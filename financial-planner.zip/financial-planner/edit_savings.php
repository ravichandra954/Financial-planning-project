<?php
// edit_savings.php - Edit Savings Goal Page
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
include 'database.php';
if (!isset($_GET['id'])) {
    header("Location: track_savings.php");
    exit();
}

$savings_id = $_GET['id'];
$user_id = $_SESSION['user_id'];
$sql = "SELECT goal_name, target_amount, saved_amount, deadline FROM savings WHERE id = ? AND user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $savings_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header("Location: track_savings.php");
    exit();
}

$savings = $result->fetch_assoc();
$stmt->close();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $goal_name = $_POST['goal_name'];
    $target_amount = $_POST['target_amount'];
    $saved_amount = $_POST['saved_amount'];
    $deadline = $_POST['deadline'];

    $update_sql = "UPDATE savings SET goal_name = ?, target_amount = ?, saved_amount = ?, deadline = ? WHERE id = ? AND user_id = ?";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bind_param("sddsii", $goal_name, $target_amount, $saved_amount, $deadline, $savings_id, $user_id);

    if ($update_stmt->execute()) {
        header("Location: track_savings.php");
        exit();
    } else {
        echo "Error: " . $update_stmt->error;
    }
    $update_stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Savings Goal</title>
    <link href="./assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="./assets/css/sb-admin-2.min.css" rel="stylesheet">
    <script src="./assets/vendor/jquery/jquery.min.js"></script>
    <script src="./assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="./assets/vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="./assets/js/sb-admin-2.min.js"></script>
</head>
<body id="page-top">
    <div id="wrapper">
        <?php include './includes/sidebar.php'; ?>
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <?php include './includes/topbar.php'; ?>
                <div class="container-fluid">
                    <h1 class="h3 mb-4 text-gray-800">Edit Savings Goal</h1>
                    <div class="card shadow mb-4">
                        <div class="card-body">
                            <form method="POST">
                                <div class="form-group">
                                    <label>Goal Name</label>
                                    <input type="text" name="goal_name" class="form-control" value="<?php echo htmlspecialchars($savings['goal_name']); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label>Target Amount</label>
                                    <input type="number" name="target_amount" class="form-control" value="<?php echo htmlspecialchars($savings['target_amount']); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label>Saved Amount</label>
                                    <input type="number" name="saved_amount" class="form-control" value="<?php echo htmlspecialchars($savings['saved_amount']); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label>Deadline</label>
                                    <input type="date" name="deadline" class="form-control" value="<?php echo htmlspecialchars($savings['deadline']); ?>" required>
                                </div>
                                <button type="submit" class="btn btn-primary">Update Goal</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <?php include './includes/footer.php'; ?>
        </div>
    </div>
</body>
</html>
