<?php
// export_data.php - Export Financial Data (CSV/PDF)
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
include 'database.php';
$user_id = $_SESSION['user_id'];
$format = isset($_GET['format']) ? $_GET['format'] : 'csv';

$sql = "SELECT 'Expense' as type, category as name, amount, date FROM expenses WHERE user_id = ? 
        UNION ALL
        SELECT 'Income' as type, source as name, amount, date FROM income WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $user_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();
$data = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();
$conn->close();

if ($format == 'csv') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="financial_data.csv"');
    
    $output = fopen('php://output', 'w');
    fputcsv($output, array('Type', 'Category/Source', 'Amount', 'Date'));
    
    foreach ($data as $row) {
        fputcsv($output, $row);
    }
    fclose($output);
    exit();
} elseif ($format == 'pdf') {
    require '../vendor/autoload.php';
    
    $mpdf = new \Mpdf\Mpdf();
    $html = '<h2>Financial Data</h2><table border="1" width="100%"><tr><th>Type</th><th>Category/Source</th><th>Amount</th><th>Date</th></tr>';
    
    foreach ($data as $row) {
        $html .= '<tr><td>' . htmlspecialchars($row['type']) . '</td><td>' . htmlspecialchars($row['name']) . '</td><td>' . $row['amount'] . '</td><td>' . $row['date'] . '</td></tr>';
    }
    
    $html .= '</table>';
    $mpdf->WriteHTML($html);
    $mpdf->Output('financial_data.pdf', 'D');
    exit();
}
?>
