<!-- sidebar.php - Sidebar Navigation -->
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="dashboard.php">
        <div class="sidebar-brand-icon">
            <i class="fas fa-chart-line"></i>
        </div>
        <div class="sidebar-brand-text mx-3">Finance Manager</div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item">
        <a class="nav-link" href="dashboard.php">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span></a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    <div class="sidebar-heading">Manage Finances</div>

    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseExpenses" aria-expanded="true" aria-controls="collapseExpenses">
            <i class="fas fa-money-bill-wave"></i>
            <span>Expenses</span>
        </a>
        <div id="collapseExpenses" class="collapse" aria-labelledby="headingExpenses" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="view_expenses.php">View Expenses</a>
                <a class="collapse-item" href="add_expense.php">Add Expense</a>
            </div>
        </div>
    </li>
    
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseIncome" aria-expanded="true" aria-controls="collapseIncome">
            <i class="fas fa-wallet"></i>
            <span>Income</span>
        </a>
        <div id="collapseIncome" class="collapse" aria-labelledby="headingIncome" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="view_income.php">View Income</a>
                <a class="collapse-item" href="add_income.php">Add Income</a>
            </div>
        </div>
    </li>
    
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseBudget" aria-expanded="true" aria-controls="collapseBudget">
            <i class="fas fa-balance-scale"></i>
            <span>Budget</span>
        </a>
        <div id="collapseBudget" class="collapse" aria-labelledby="headingBudget" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="view_budget.php">View Budget</a>
                <a class="collapse-item" href="set_budget.php">Set Budget</a>
            </div>
        </div>
    </li>
    
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseSavings" aria-expanded="true" aria-controls="collapseSavings">
            <i class="fas fa-piggy-bank"></i>
            <span>Savings Goals</span>
        </a>
        <div id="collapseSavings" class="collapse" aria-labelledby="headingSavings" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="track_savings.php">Track Savings</a>
                <a class="collapse-item" href="set_savings.php">Set Savings Goal</a>
            </div>
        </div>
    </li>
    
    <li class="nav-item">
        <a class="nav-link" href="generate_report.php">
            <i class="fas fa-chart-pie"></i>
            <span>Financial Reports</span></a>
    </li>
    
    <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseReminders" aria-expanded="true" aria-controls="collapseReminders">
            <i class="fas fa-bell"></i>
            <span>Bill Reminders</span>
        </a>
        <div id="collapseReminders" class="collapse" aria-labelledby="headingReminders" data-parent="#accordionSidebar">
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="bill_reminders.php">View Reminders</a>
                <a class="collapse-item" href="add_bill.php">Add Reminder</a>
            </div>
        </div>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <div class="sidebar-heading">User Settings</div>
    <li class="nav-item">
        <a class="nav-link" href="settings.php">
            <i class="fas fa-cogs"></i>
            <span>Settings</span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="admin_profile.php">
            <i class="fas fa-user"></i>
            <span>Profile</span></a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="logout.php">
            <i class="fas fa-sign-out-alt"></i>
            <span>Logout</span></a>
    </li>
</ul>
