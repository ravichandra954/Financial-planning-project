<?php
// delete_income.php - Delete Income
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
include 'database.php';
if (!isset($_GET['id'])) {
    header("Location: view_income.php");
    exit();
}

$income_id = $_GET['id'];
$user_id = $_SESSION['user_id'];

$sql = "DELETE FROM income WHERE id = ? AND user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $income_id, $user_id);

if ($stmt->execute()) {
    header("Location: view_income.php");
    exit();
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
