<?php
// delete_savings.php - Delete Savings Goal
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
include 'database.php';
if (!isset($_GET['id'])) {
    header("Location: track_savings.php");
    exit();
}

$savings_id = $_GET['id'];
$user_id = $_SESSION['user_id'];

$sql = "DELETE FROM savings WHERE id = ? AND user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $savings_id, $user_id);

if ($stmt->execute()) {
    header("Location: track_savings.php");
    exit();
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
