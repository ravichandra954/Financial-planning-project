<?php
// edit_income.php - Edit Income Page
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
include 'database.php';
if (!isset($_GET['id'])) {
    header("Location: view_income.php");
    exit();
}

$income_id = $_GET['id'];
$user_id = $_SESSION['user_id'];
$sql = "SELECT source, amount, date FROM income WHERE id = ? AND user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $income_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header("Location: view_income.php");
    exit();
}

$income = $result->fetch_assoc();
$stmt->close();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $source = $_POST['source'];
    $amount = $_POST['amount'];
    $date = $_POST['date'];

    $update_sql = "UPDATE income SET source = ?, amount = ?, date = ? WHERE id = ? AND user_id = ?";
    $update_stmt = $conn->prepare($update_sql);
    $update_stmt->bind_param("sdsii", $source, $amount, $date, $income_id, $user_id);

    if ($update_stmt->execute()) {
        header("Location: view_income.php");
        exit();
    } else {
        echo "Error: " . $update_stmt->error;
    }
    $update_stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Income</title>
    <link href="./assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="./assets/css/sb-admin-2.min.css" rel="stylesheet">
    <script src="./assets/vendor/jquery/jquery.min.js"></script>
    <script src="./assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="./assets/vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="./assets/js/sb-admin-2.min.js"></script>
</head>
<body id="page-top">
    <div id="wrapper">
        <?php include './includes/sidebar.php'; ?>
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <?php include './includes/topbar.php'; ?>
                <div class="container-fluid">
                    <h1 class="h3 mb-4 text-gray-800">Edit Income</h1>
                    <div class="card shadow mb-4">
                        <div class="card-body">
                            <form method="POST">
                                <div class="form-group">
                                    <label>Source</label>
                                    <input type="text" name="source" class="form-control" value="<?php echo htmlspecialchars($income['source']); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label>Amount</label>
                                    <input type="number" name="amount" class="form-control" value="<?php echo htmlspecialchars($income['amount']); ?>" required>
                                </div>
                                <div class="form-group">
                                    <label>Date</label>
                                    <input type="date" name="date" class="form-control" value="<?php echo htmlspecialchars($income['date']); ?>" required>
                                </div>
                                <button type="submit" class="btn btn-primary">Update Income</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <?php include './includes/footer.php'; ?>
        </div>
    </div>
</body>
</html>