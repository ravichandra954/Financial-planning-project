<?php
// set_savings.php - Set Savings Goal Page
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
include 'database.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id'];
    $goal_name = $_POST['goal_name'];
    $target_amount = $_POST['target_amount'];
    $saved_amount = $_POST['saved_amount'];
    $deadline = $_POST['deadline'];

    $sql = "INSERT INTO savings (user_id, goal_name, target_amount, saved_amount, deadline) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isdds", $user_id, $goal_name, $target_amount, $saved_amount, $deadline);
    if ($stmt->execute()) {
        header("Location: track_savings.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Set Savings Goal</title>
    <link href="./assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="./assets/css/sb-admin-2.min.css" rel="stylesheet">
    <script src="./assets/vendor/jquery/jquery.min.js"></script>
    <script src="./assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="./assets/vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="./assets/js/sb-admin-2.min.js"></script>
</head>
<body id="page-top">
    <div id="wrapper">
        <?php include './includes/sidebar.php'; ?>
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <?php include './includes/topbar.php'; ?>
                <div class="container-fluid">
                    <h1 class="h3 mb-4 text-gray-800">Set Savings Goal</h1>
                    <div class="card shadow mb-4">
                        <div class="card-body">
                            <form method="POST">
                                <div class="form-group">
                                    <label>Goal Name</label>
                                    <input type="text" name="goal_name" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label>Target Amount</label>
                                    <input type="number" name="target_amount" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label>Saved Amount</label>
                                    <input type="number" name="saved_amount" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label>Deadline</label>
                                    <input type="date" name="deadline" class="form-control" required>
                                </div>
                                <button type="submit" class="btn btn-primary">Set Goal</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <?php include './includes/footer.php'; ?>
        </div>
    </div>
</body>
</html>