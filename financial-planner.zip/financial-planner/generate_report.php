<?php
// generate_report.php - Generate Financial Report
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
include 'database.php';

$user_id = $_SESSION['user_id'];

// Fetch expenses
$sql_expenses = "SELECT category, SUM(amount) as total FROM expenses WHERE user_id = ? GROUP BY category";
$stmt_expenses = $conn->prepare($sql_expenses);
$stmt_expenses->bind_param("i", $user_id);
$stmt_expenses->execute();
$result_expenses = $stmt_expenses->get_result();

$expense_data = [];
while ($row = $result_expenses->fetch_assoc()) {
    $expense_data[] = $row;
}
$stmt_expenses->close();

// Fetch income
$sql_income = "SELECT source, SUM(amount) as total FROM income WHERE user_id = ? GROUP BY source";
$stmt_income = $conn->prepare($sql_income);
$stmt_income->bind_param("i", $user_id);
$stmt_income->execute();
$result_income = $stmt_income->get_result();

$income_data = [];
while ($row = $result_income->fetch_assoc()) {
    $income_data[] = $row;
}
$stmt_income->close();

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Financial Report</title>
    <link href="./assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="./assets/css/sb-admin-2.min.css" rel="stylesheet">
    <script src="./assets/vendor/jquery/jquery.min.js"></script>
    <script src="./assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="./assets/vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="./assets/js/sb-admin-2.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script> <!-- Load Chart.js -->
</head>
<body id="page-top">
    <div id="wrapper">
        <?php include './includes/sidebar.php'; ?>
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <?php include './includes/topbar.php'; ?>
                <div class="container-fluid">
                    <h1 class="h3 mb-4 text-gray-800">Financial Report</h1>

                    <!-- Export Report Buttons -->
                    <div class="mb-3">
                        <a href="export_data.php?format=csv" class="btn btn-success btn-sm">
                            <i class="fas fa-file-csv"></i> Download CSV
                        </a>
                       
                    </div>

                    <div class="card shadow mb-4">
                        <div class="card-body">
                            <h4>Expense Summary</h4>
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Category</th>
                                        <th>Total Amount</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($expense_data as $row) { ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($row['category']); ?></td>
                                            <td><?php echo number_format($row['total'], 2); ?></td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="card shadow mb-4">
                        <div class="card-body">
                            <h4>Income Summary</h4>
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Source</th>
                                        <th>Total Amount</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($income_data as $row) { ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($row['source']); ?></td>
                                            <td><?php echo number_format($row['total'], 2); ?></td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-6">
                            <div class="card shadow mb-4">
                                <div class="card-body">
                                    <h4>Expense Chart</h4>
                                    <canvas id="expenseChart"></canvas> <!-- Pie Chart -->
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-lg-6">
                            <div class="card shadow mb-4">
                                <div class="card-body">
                                    <h4>Income Chart</h4>
                                    <canvas id="incomeChart"></canvas> <!-- Bar Graph -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php include './includes/footer.php'; ?>
        </div>
    </div>

    <script>
        // Prepare data for JavaScript
        var expenseLabels = <?php echo json_encode(array_column($expense_data, 'category')); ?>;
        var expenseValues = <?php echo json_encode(array_column($expense_data, 'total')); ?>;

        var incomeLabels = <?php echo json_encode(array_column($income_data, 'source')); ?>;
        var incomeValues = <?php echo json_encode(array_column($income_data, 'total')); ?>;

        // Expense Pie Chart
        var ctxExpense = document.getElementById('expenseChart').getContext('2d');
        var expenseChart = new Chart(ctxExpense, {
            type: 'pie',
            data: {
                labels: expenseLabels,
                datasets: [{
                    label: 'Expenses',
                    data: expenseValues,
                    backgroundColor: ['#ff6384', '#36a2eb', '#ffce56', '#4bc0c0', '#9966ff', '#ff9f40'],
                }]
            }
        });

        // Income Bar Graph
        var ctxIncome = document.getElementById('incomeChart').getContext('2d');
        var incomeChart = new Chart(ctxIncome, {
            type: 'bar',
            data: {
                labels: incomeLabels,
                datasets: [{
                    label: 'Income',
                    data: incomeValues,
                    backgroundColor: '#36a2eb',
                    borderColor: '#1e88e5',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>
</html>
