<?php
function log_security_event($event_type, $description, $user_id = null) {
    // Ensure you have a PDO connection object
    global $pdo;

    // Get the user's IP address
    $ip_address = $_SERVER['REMOTE_ADDR'];

    // Prepare the SQL query to insert a log entry into the database
    $stmt = $pdo->prepare("INSERT INTO security_logs (event_type, description, user_id, ip_address) 
                           VALUES (:event_type, :description, :user_id, :ip_address)");
    $stmt->execute([
        ':event_type' => $event_type,
        ':description' => $description,
        ':user_id' => $user_id,
        ':ip_address' => $ip_address
    ]);
}
?>