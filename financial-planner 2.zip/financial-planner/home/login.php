<?php
// login.php - User Login
session_start();
include '../database.php'; // Database connection

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $conn->prepare("SELECT id, username, password FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();
    $stmt->bind_result($id, $username, $stored_password);
    $stmt->fetch();

    if ($stmt->num_rows > 0 && $password === $stored_password) {
        $_SESSION['user_id'] = $id;
        $_SESSION['username'] = $username;
        header("Location: ../dashboard.php");
        exit();
    } else {
        $error = "Invalid credentials";
    }
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login</title>
  <link href="../assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="../assets/css/sb-admin-2.min.css" rel="stylesheet">
  <script src="../assets/vendor/jquery/jquery.min.js"></script>
  <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/vendor/jquery-easing/jquery.easing.min.js"></script>
  <script src="../assets/js/sb-admin-2.min.js"></script>
</head>
<body class="bg-gradient-primary">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-xl-8 col-lg-10 col-md-7">
          <div class="card o-hidden border-0 shadow-lg my-5">
            <div class="card-body p-1">
                
                <div class="col-lg-12">
                  <div class="p-5">
                    <div class="text-center">
                      <h1 class="h4 text-gray-900 mb-4">Welcome Back!</h1>
                    </div>
                    <form class="user" action="" method="POST">
                      <div class="form-group">
                        <input type="text" name="username" class="form-control form-control-user" placeholder="Enter Username" required>
                      </div>
                      <div class="form-group">
                        <input type="password" name="password" class="form-control form-control-user" placeholder="Password" required>
                      </div>
                      <button type="submit" class="btn btn-primary btn-user btn-block">Login</button>
                    </form>
                    <?php if (isset($error)): ?>
                        <p class="text-danger text-center mt-2"><?php echo $error; ?></p>
                    <?php endif; ?>
                    <hr>
                    <div class="text-center">
                      <a class="small" href="#">Forgot Password?</a>
                    </div>
                  </div>
                </div>
            </div>
          </div>
        </div>
      </div>
    </div>
</body>
</html>