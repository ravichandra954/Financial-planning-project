<?php
// index.php - Redirect to Home Folder
header("Location: home/");
exit();
?>