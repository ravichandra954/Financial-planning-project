<!-- footer.php - Footer Section -->
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; Finance App <?php echo date("Y"); ?></span>
        </div>
    </div>
</footer>